# Tidewrack for Android

Needs: Node.js 18+ and Android Studio (with its SDK).

1. In this folder run:  npm install
2. Then:  npx cap add android
3. Then:  npx cap sync android
4. Then:  npx cap open android
5. In Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
   The file is app/build/outputs/apk/debug/app-debug.apk. Copy it to your phone and open it
   (allow "install unknown apps" when asked).

Notes
- Your posts and brands are saved on the phone inside the app.
- The "Write with AI" and Autopilot writer buttons only work inside Claude, so they stay hidden in this app.
- Auto-publish only marks posts as published inside the app. Real posting needs a connected service.
- To update the app later, replace www/index.html and run: npx cap sync android

## No Android Studio? Build the APK in the cloud (free)
1. Create a free GitHub account and a new repository.
2. Upload everything in this folder (including the hidden .github folder) to the main branch.
3. Open the Actions tab, choose "Build APK", then Run workflow.
4. When it finishes (about 5 minutes), download "tidewrack-apk" from the run page, unzip it, and install app-debug.apk on your phone.
